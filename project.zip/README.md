# Empathic Credit System (ECS) Project

This project implements a fictional ECS system as per the technical case.

Para dat setup no projeto basta usar `docker-compose up --build`